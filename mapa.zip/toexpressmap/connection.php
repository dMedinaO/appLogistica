<?php

	$server = "localhost";
	$user = "toexpress";
	$password = "toexpress"; //poner tu propia contraseña, si tienes una.
	$bd = "toexpress";
	$secret = "c85ae6f5bbf337301e33bb5ee0d13f9a7a3e2148";

?>
